///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image: " << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		int textureSlot = FindTextureSlot(textureTag);

		// if the texture tag was not found (the image failed to load),
		if (textureSlot == -1)
		{
			// turn texturing off so the shape falls back to its shader color
			m_pShaderManager->setIntValue(g_UseTextureName, false);
			return;
		}

		m_pShaderManager->setIntValue(g_UseTextureName, true);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

// dimensions shared by several objects in the desk scene
namespace
{
	// monitor body
	const float MONITOR_Z = -3.0f;		// depth position of the monitor body
	const float MONITOR_WIDTH = 14.0f;
	const float MONITOR_DEPTH = 0.5f;
	const float CHIN_BOTTOM = 1.6f;		// height of the lower edge of the silver chin
	const float CHIN_HEIGHT = 1.6f;
	const float BEZEL_HEIGHT = 8.0f;

	// mug, positioned by the center of its base
	const glm::vec3 MUG_POSITION(-6.6f, 0.0f, 0.6f);
	const float MUG_RADIUS = 1.0f;		// radius at the rim (widest point)
	const float MUG_HEIGHT = 2.2f;

	// square pencil cup, positioned by the center of its base
	const glm::vec3 CUP_POSITION(9.2f, 0.0f, 0.8f);
	const float CUP_WIDTH = 2.0f;
	const float CUP_HEIGHT = 1.8f;
	const float CUP_WALL = 0.08f;
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading the texture images used
 *  by the 3D scene and binding them to texture slots.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// rows of RGB image data are tightly packed, so tell OpenGL not to
	// expect 4-byte row padding; this prevents reading past the end of
	// images whose width is not a multiple of 4
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// load each texture image and assign it a tag for later reference
	CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "rusticwood");
	CreateGLTexture("../../Utilities/textures/drywall.jpg", "drywall");
	CreateGLTexture("../../Utilities/textures/stainedglass.jpg", "stainedglass");
	CreateGLTexture("../../Utilities/textures/coffe.jpeg", "coffee");

	// bind the loaded textures to the available texture slots
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the material settings
 *  for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// The fragment shader adds the material ambient term once for each of
	// its 4 light slots, so a small ambient value already keeps every
	// surface out of complete shadow.

	// varnish: desk surface; a strong specular term so the desk visibly
	// reflects the lights
	OBJECT_MATERIAL varnishMaterial;
	varnishMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	varnishMaterial.ambientStrength = 0.5f;
	varnishMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	varnishMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	varnishMaterial.shininess = 16.0;
	varnishMaterial.tag = "varnish";
	m_objectMaterials.push_back(varnishMaterial);

	// wall: flat painted drywall with almost no shine
	OBJECT_MATERIAL wallMaterial;
	wallMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	wallMaterial.ambientStrength = 0.5f;
	wallMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	wallMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	wallMaterial.shininess = 1.0;
	wallMaterial.tag = "wall";
	m_objectMaterials.push_back(wallMaterial);

	// plastic: keyboard, mouse, monitor bezel, and pencil bodies
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	plasticMaterial.ambientStrength = 0.5f;
	plasticMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	plasticMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	plasticMaterial.shininess = 20.0;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	// metal: brushed aluminum of the monitor chin and stand
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	metalMaterial.ambientStrength = 0.5f;
	metalMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
	metalMaterial.shininess = 40.0;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	// screen: a high ambient value saturates to white, so the blank
	// screen looks like it emits its own light
	OBJECT_MATERIAL screenMaterial;
	screenMaterial.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMaterial.ambientStrength = 0.5f;
	screenMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	screenMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	screenMaterial.shininess = 1.0;
	screenMaterial.tag = "screen";
	m_objectMaterials.push_back(screenMaterial);

	// ceramic: glazed mug and pencil cup with tight, bright highlights
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	ceramicMaterial.ambientStrength = 0.5f;
	ceramicMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	ceramicMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	ceramicMaterial.shininess = 32.0;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	// liquid: the surface of the coffee, slightly glossy
	OBJECT_MATERIAL liquidMaterial;
	liquidMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	liquidMaterial.ambientStrength = 0.5f;
	liquidMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	liquidMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	liquidMaterial.shininess = 24.0;
	liquidMaterial.tag = "liquid";
	m_objectMaterials.push_back(liquidMaterial);

	// paper: notebooks and the bare wood of the pencil tips; fully matte
	OBJECT_MATERIAL paperMaterial;
	paperMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	paperMaterial.ambientStrength = 0.5f;
	paperMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	paperMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	paperMaterial.shininess = 0.0;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Notes on the course fragment shader that shape these settings:
	// - it always loops over all 4 light slots, so unused slots must still
	//   be filled with safe values (see lights 2 and 3 below)
	// - the diffuse term uses the material diffuse color, not the light's,
	//   so a light's color reaches the scene through its ambient color
	// - specular strength is specularIntensity times material shininess,
	//   so the intensities are kept small

	// light 0: daylight from a window to the front left, high above the
	// desk; it lights the faces of the objects that face the camera
	m_pShaderManager->setVec3Value("lightSources[0].position", -6.0f, 12.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.12f, 0.12f, 0.12f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 24.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.15f);

	// light 1: warm desk lamp, low and behind the scene on the right; from
	// the default camera view its highlight reflects off the varnished
	// desk between the mouse and the pencil cup
	m_pShaderManager->setVec3Value("lightSources[1].position", 12.0f, 3.0f, -2.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.08f, 0.05f, 0.02f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 1.0f, 0.8f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 1.0f, 0.85f, 0.7f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.12f);

	// lights 2 and 3 are not used. If left unset, their focal strength is
	// 0 and the shader computes pow(0, 0), which some graphics drivers
	// return as NaN and draw as black pixels. A focal strength of 1 avoids
	// that, zero intensity removes their highlights, and placing them far
	// below the desk keeps their diffuse term off every visible surface.
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, -100.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.0f);

	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, -100.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);

	// turn on lighting in the fragment shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// each mesh is loaded once and reused for every object that needs it
	m_basicMeshes->LoadPlaneMesh();				// desk and wall
	m_basicMeshes->LoadBoxMesh();				// monitor, keyboard, notebooks, cup
	m_basicMeshes->LoadSphereMesh();			// mouse
	m_basicMeshes->LoadTaperedCylinderMesh();	// mug body
	m_basicMeshes->LoadTorusMesh();				// mug handle
	m_basicMeshes->LoadCylinderMesh();			// coffee surface and pencil bodies
	m_basicMeshes->LoadConeMesh();				// sharpened pencil tips
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  drawing each group of objects on the desk
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDeskAndWall();
	RenderMonitor();
	RenderKeyboardAndMouse();
	RenderNotebooks();
	RenderMug();
	RenderPencilCup();
}

/***********************************************************
 *  RenderDeskAndWall()
 *
 *  Draws the textured desk surface and the back wall.
 ***********************************************************/
void SceneManager::RenderDeskAndWall()
{
	// desk surface: the wood texture is tiled 4 x 4 so the grain keeps a
	// realistic size, and the varnish material reflects the lights
	SetTransformations(glm::vec3(15.0f, 1.0f, 10.0f), 0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));
	SetShaderColor(0.86f, 0.85f, 0.84f, 1.0f);
	SetShaderMaterial("varnish");
	SetTextureUVScale(4.0f, 4.0f);
	SetShaderTexture("rusticwood");
	m_basicMeshes->DrawPlaneMesh();

	// back wall: the plane is stood upright and raised so its bottom edge
	// meets the back of the desk
	SetTransformations(glm::vec3(15.0f, 1.0f, 10.0f), 90.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 10.0f, -10.0f));
	SetShaderColor(0.94f, 0.94f, 0.95f, 1.0f);
	SetShaderMaterial("wall");
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderTexture("drywall");
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderMonitor()
 *
 *  Draws the widescreen monitor: stand, aluminum chin, black
 *  bezel, and the blank white screen.
 ***********************************************************/
void SceneManager::RenderMonitor()
{
	const float chinCenterY = CHIN_BOTTOM + CHIN_HEIGHT / 2.0f;
	const float bezelCenterY = CHIN_BOTTOM + CHIN_HEIGHT + BEZEL_HEIGHT / 2.0f;

	// aluminum stand: a thin base plate and a neck behind the chin
	SetShaderColor(0.78f, 0.79f, 0.80f, 1.0f);
	SetShaderMaterial("metal");

	SetTransformations(glm::vec3(4.4f, 0.15f, 3.0f), 0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.075f, MONITOR_Z + 0.2f));
	m_basicMeshes->DrawBoxMesh();

	SetTransformations(glm::vec3(2.4f, 1.6f, 0.4f), 0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 0.95f, MONITOR_Z - 0.1f));
	m_basicMeshes->DrawBoxMesh();

	// aluminum chin below the screen
	SetTransformations(glm::vec3(MONITOR_WIDTH, CHIN_HEIGHT, MONITOR_DEPTH), 0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, chinCenterY, MONITOR_Z));
	m_basicMeshes->DrawBoxMesh();

	// black bezel around the screen
	SetShaderColor(0.06f, 0.06f, 0.06f, 1.0f);
	SetShaderMaterial("plastic");
	SetTransformations(glm::vec3(MONITOR_WIDTH, BEZEL_HEIGHT, MONITOR_DEPTH), 0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, bezelCenterY, MONITOR_Z));
	m_basicMeshes->DrawBoxMesh();

	// blank white screen set just in front of the bezel, leaving a
	// black border of 0.4 on every side
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("screen");
	SetTransformations(glm::vec3(MONITOR_WIDTH - 0.8f, BEZEL_HEIGHT - 0.8f, 0.05f), 0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, bezelCenterY, MONITOR_Z + MONITOR_DEPTH / 2.0f + 0.025f));
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderKeyboardAndMouse()
 *
 *  Draws the white keyboard with a grid of keys and the
 *  rounded mouse to its right.
 ***********************************************************/
void SceneManager::RenderKeyboardAndMouse()
{
	const glm::vec3 keyboardCenter(-1.0f, 0.0f, 3.4f);
	const float baseHeight = 0.25f;
	const float keySpacing = 0.68f;
	const int keyRows = 4;
	const int keyColumns = 14;

	SetShaderMaterial("plastic");

	// keyboard base
	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	SetTransformations(glm::vec3(10.2f, baseHeight, 3.0f), 0.0f, 0.0f, 0.0f,
		glm::vec3(keyboardCenter.x, baseHeight / 2.0f, keyboardCenter.z));
	m_basicMeshes->DrawBoxMesh();

	// keys: a grid of small boxes centered on the base
	SetShaderColor(0.85f, 0.86f, 0.88f, 1.0f);
	const float firstKeyX = keyboardCenter.x - (keyColumns - 1) * keySpacing / 2.0f;
	const float firstKeyZ = keyboardCenter.z - (keyRows - 1) * keySpacing / 2.0f;
	for (int row = 0; row < keyRows; row++)
	{
		for (int column = 0; column < keyColumns; column++)
		{
			SetTransformations(glm::vec3(0.55f, 0.1f, 0.55f), 0.0f, 0.0f, 0.0f,
				glm::vec3(firstKeyX + column * keySpacing, baseHeight + 0.05f,
					firstKeyZ + row * keySpacing));
			m_basicMeshes->DrawBoxMesh();
		}
	}

	// Mouse body: a sphere flattened into a low ellipsoid. Its center sits
	// just under the desk so the bottom half is hidden and only a dome
	// shows. The 10 degree X tilt drops the front end and lifts the back,
	// which gives the wedge profile of a real mouse instead of the
	// symmetric half ball a level sphere would produce.
	const glm::vec3 mouseCenter(5.6f, -0.04f, keyboardCenter.z);
	const float mouseWidth = 0.72f;
	const float mouseHeight = 0.50f;
	const float mouseDepth = 1.15f;
	const float mouseTilt = 10.0f;

	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	SetTransformations(glm::vec3(mouseWidth, mouseHeight, mouseDepth),
		mouseTilt, 0.0f, 0.0f, mouseCenter);
	m_basicMeshes->DrawSphereMesh();

	// Scroll wheel: the cylinder mesh runs along its own Y axis, so a 90
	// degree Z rotation lays it on its side to spin front to back. That
	// rotation also swings its base off the origin, so half its length is
	// added back on X to keep it centered. It is set low enough that most
	// of it stays buried in the shell, leaving only the rim exposed.
	const float wheelRadius = 0.09f;
	const float wheelWidth = 0.10f;

	SetShaderColor(0.35f, 0.35f, 0.38f, 1.0f);
	SetTransformations(glm::vec3(wheelRadius, wheelWidth, wheelRadius),
		0.0f, 0.0f, 90.0f,
		glm::vec3(mouseCenter.x + wheelWidth / 2.0f, 0.34f, mouseCenter.z + 0.30f));
	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  RenderNotebooks()
 *
 *  Draws a stack of five monochrome notebooks, thickest at
 *  the bottom and smallest on top.
 ***********************************************************/
void SceneManager::RenderNotebooks()
{
	const glm::vec3 stackBase(-10.4f, 0.0f, 0.5f);
	const int bookCount = 5;

	// size of each notebook (width, thickness, depth), bottom to top
	const glm::vec3 bookSizes[bookCount] = {
		glm::vec3(4.2f, 0.60f, 3.0f),
		glm::vec3(4.0f, 0.50f, 2.9f),
		glm::vec3(3.9f, 0.45f, 2.8f),
		glm::vec3(3.7f, 0.35f, 2.7f),
		glm::vec3(3.5f, 0.30f, 2.6f) };

	// small turns so the stack does not look perfectly aligned
	const float bookTurns[bookCount] = { 2.0f, -3.0f, 4.0f, -2.0f, 3.0f };

	// alternating dark and light covers
	const glm::vec3 bookColors[bookCount] = {
		glm::vec3(0.15f, 0.15f, 0.17f),
		glm::vec3(0.92f, 0.92f, 0.90f),
		glm::vec3(0.25f, 0.25f, 0.27f),
		glm::vec3(0.80f, 0.80f, 0.80f),
		glm::vec3(0.10f, 0.10f, 0.12f) };

	SetShaderMaterial("paper");

	// each book rests on top of the one below it
	float stackHeight = stackBase.y;
	for (int i = 0; i < bookCount; i++)
	{
		DrawNotebook(glm::vec3(stackBase.x, stackHeight, stackBase.z),
			bookSizes[i], bookTurns[i], bookColors[i]);

		stackHeight += bookSizes[i].y;
	}
}

/***********************************************************
 *  RenderMug()
 *
 *  Draws the textured mug: an open tapered body, the coffee
 *  inside it, and the looped handle.
 ***********************************************************/
void SceneManager::RenderMug()
{
	SetShaderMaterial("ceramic");

	// body: the tapered cylinder is flipped 180 degrees so the wide end
	// becomes the rim; the stained glass pattern repeats 3 times around
	// the mug so it wraps the curved body without being stretched
	SetTransformations(glm::vec3(MUG_RADIUS, MUG_HEIGHT, MUG_RADIUS), 180.0f, 0.0f, 0.0f,
		MUG_POSITION + glm::vec3(0.0f, MUG_HEIGHT, 0.0f));
	SetShaderColor(0.17f, 0.17f, 0.18f, 1.0f);
	SetTextureUVScale(3.0f, 1.0f);
	SetShaderTexture("stainedglass");

	// the flipped mesh's bottom cap is now at the rim; skip it so the mug
	// is open and draw only the floor and the sides
	m_basicMeshes->DrawTaperedCylinderMesh(true, false, true);

	// coffee: a thin disk a little below the rim, sized to fit the
	// narrower inside of the tapered body at that depth
	SetTransformations(glm::vec3(MUG_RADIUS * 0.92f, 0.06f, MUG_RADIUS * 0.92f), 0.0f, 0.0f, 0.0f,
		MUG_POSITION + glm::vec3(0.0f, MUG_HEIGHT - 0.25f, 0.0f));
	SetShaderColor(0.22f, 0.13f, 0.07f, 1.0f);
	SetShaderMaterial("liquid");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee");
	m_basicMeshes->DrawCylinderMesh();

	// handle: sized and placed from the mug dimensions so it stays
	// attached to the body if the mug is resized
	SetTransformations(
		glm::vec3(MUG_RADIUS * 0.35f, MUG_HEIGHT * 0.32f, MUG_RADIUS * 0.27f), 0.0f, 0.0f, 0.0f,
		MUG_POSITION + glm::vec3(MUG_RADIUS * 0.9f, MUG_HEIGHT * 0.52f, 0.0f));
	SetShaderColor(0.17f, 0.17f, 0.18f, 1.0f);
	SetShaderMaterial("ceramic");
	SetShaderTexture("stainedglass");
	m_basicMeshes->DrawTorusMesh();
}

/***********************************************************
 *  RenderPencilCup()
 *
 *  Draws the open square pencil cup and the six pencils
 *  standing in it with their points facing upward.
 ***********************************************************/
void SceneManager::RenderPencilCup()
{
	const float halfWidth = CUP_WIDTH / 2.0f;
	const float wallOffset = halfWidth - CUP_WALL / 2.0f;
	const float wallCenterY = CUP_HEIGHT / 2.0f;

	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	SetShaderMaterial("ceramic");

	// floor of the cup
	SetTransformations(glm::vec3(CUP_WIDTH, 0.1f, CUP_WIDTH), 0.0f, 0.0f, 0.0f,
		CUP_POSITION + glm::vec3(0.0f, 0.05f, 0.0f));
	m_basicMeshes->DrawBoxMesh();

	// left and right walls span the full depth of the cup
	SetTransformations(glm::vec3(CUP_WALL, CUP_HEIGHT, CUP_WIDTH), 0.0f, 0.0f, 0.0f,
		CUP_POSITION + glm::vec3(-wallOffset, wallCenterY, 0.0f));
	m_basicMeshes->DrawBoxMesh();
	SetTransformations(glm::vec3(CUP_WALL, CUP_HEIGHT, CUP_WIDTH), 0.0f, 0.0f, 0.0f,
		CUP_POSITION + glm::vec3(wallOffset, wallCenterY, 0.0f));
	m_basicMeshes->DrawBoxMesh();

	// front and back walls fit between the side walls
	SetTransformations(glm::vec3(CUP_WIDTH - 2.0f * CUP_WALL, CUP_HEIGHT, CUP_WALL), 0.0f, 0.0f, 0.0f,
		CUP_POSITION + glm::vec3(0.0f, wallCenterY, -wallOffset));
	m_basicMeshes->DrawBoxMesh();
	SetTransformations(glm::vec3(CUP_WIDTH - 2.0f * CUP_WALL, CUP_HEIGHT, CUP_WALL), 0.0f, 0.0f, 0.0f,
		CUP_POSITION + glm::vec3(0.0f, wallCenterY, wallOffset));
	m_basicMeshes->DrawBoxMesh();

	// six pencils standing on the cup floor, each leaning slightly
	// outward so they fan open like in the reference image
	const glm::vec3 floorTop = CUP_POSITION + glm::vec3(0.0f, 0.1f, 0.0f);
	DrawPencil(floorTop + glm::vec3(-0.45f, 0.0f, -0.35f), -6.0f, 8.0f);
	DrawPencil(floorTop + glm::vec3(0.00f, 0.0f, -0.40f), -8.0f, 0.0f);
	DrawPencil(floorTop + glm::vec3(0.45f, 0.0f, -0.35f), -5.0f, -9.0f);
	DrawPencil(floorTop + glm::vec3(-0.40f, 0.0f, 0.35f), 6.0f, 6.0f);
	DrawPencil(floorTop + glm::vec3(0.05f, 0.0f, 0.40f), 9.0f, -2.0f);
	DrawPencil(floorTop + glm::vec3(0.45f, 0.0f, 0.30f), 5.0f, -7.0f);
}

/***********************************************************
 *  DrawPencil()
 *
 *  Draws one sharpened pencil: a black body, a cone of bare
 *  wood, and a small graphite point. The pencil stands on
 *  basePosition and leans by tiltXDegrees (toward +Z) and
 *  tiltZDegrees (toward -X).
 ***********************************************************/
void SceneManager::DrawPencil(glm::vec3 basePosition, float tiltXDegrees, float tiltZDegrees)
{
	const float bodyLength = 2.7f;
	const float bodyRadius = 0.07f;
	const float tipLength = 0.25f;
	const float leadRadius = 0.025f;

	// direction the pencil points after its tilts; SetTransformations
	// applies the Z rotation first and the X rotation after it
	const float tiltX = glm::radians(tiltXDegrees);
	const float tiltZ = glm::radians(tiltZDegrees);
	const glm::vec3 direction(
		-glm::sin(tiltZ),
		glm::cos(tiltZ) * glm::cos(tiltX),
		glm::cos(tiltZ) * glm::sin(tiltX));

	// black painted body, starting at the base
	SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);
	SetShaderMaterial("plastic");
	SetTransformations(glm::vec3(bodyRadius, bodyLength, bodyRadius), tiltXDegrees, 0.0f, tiltZDegrees,
		basePosition);
	m_basicMeshes->DrawCylinderMesh();

	// sharpened wood cone on top of the body
	SetShaderColor(0.85f, 0.68f, 0.48f, 1.0f);
	SetShaderMaterial("paper");
	SetTransformations(glm::vec3(bodyRadius, tipLength, bodyRadius), tiltXDegrees, 0.0f, tiltZDegrees,
		basePosition + direction * bodyLength);
	m_basicMeshes->DrawConeMesh();

	// graphite point: starts where the wood cone narrows to the lead
	// radius, so both cones meet at the same tip
	const float leadLength = tipLength * leadRadius / bodyRadius;
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);
	SetTransformations(glm::vec3(leadRadius, leadLength, leadRadius), tiltXDegrees, 0.0f, tiltZDegrees,
		basePosition + direction * (bodyLength + tipLength - leadLength));
	m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 *  DrawNotebook()
 *
 *  Draws one notebook from four boxes: a bottom cover, a top
 *  cover, a spine down the left edge, and a block of white
 *  pages inset between them. The pages stand proud of nothing
 *  and sit back from the front, right, and rear faces, so the
 *  white page edges read against the cover on three sides.
 *
 *  bottomCenter is the center of the face resting on whatever
 *  is below, size is (width, thickness, depth), and
 *  turnDegrees rotates the whole notebook about its own Y axis.
 ***********************************************************/
void SceneManager::DrawNotebook(glm::vec3 bottomCenter, glm::vec3 size,
	float turnDegrees, glm::vec3 coverColor)
{
	// how far the pages sit back from the three open edges, and how
	// thick each cover board is
	const float pageInset = 0.07f;
	const float spineWidth = 0.10f;
	const float coverThickness = glm::min(0.06f, size.y * 0.20f);

	// Each part is positioned by an offset from the notebook center, but
	// SetTransformations rotates a mesh about its own origin and then
	// translates it, so the offsets have to be rotated here by hand to
	// follow the notebook as it turns.
	const float turn = glm::radians(turnDegrees);
	const float turnCos = glm::cos(turn);
	const float turnSin = glm::sin(turn);

	SetShaderMaterial("paper");

	// bottom cover
	SetShaderColor(coverColor.r, coverColor.g, coverColor.b, 1.0f);
	SetTransformations(glm::vec3(size.x, coverThickness, size.z),
		0.0f, turnDegrees, 0.0f,
		glm::vec3(bottomCenter.x,
			bottomCenter.y + coverThickness / 2.0f,
			bottomCenter.z));
	m_basicMeshes->DrawBoxMesh();

	// top cover
	SetTransformations(glm::vec3(size.x, coverThickness, size.z),
		0.0f, turnDegrees, 0.0f,
		glm::vec3(bottomCenter.x,
			bottomCenter.y + size.y - coverThickness / 2.0f,
			bottomCenter.z));
	m_basicMeshes->DrawBoxMesh();

	// spine: a narrow board closing the left edge, so the pages only
	// show on the other three sides
	const float spineOffsetX = -(size.x - spineWidth) / 2.0f;
	SetTransformations(glm::vec3(spineWidth, size.y, size.z),
		0.0f, turnDegrees, 0.0f,
		glm::vec3(bottomCenter.x + spineOffsetX * turnCos,
			bottomCenter.y + size.y / 2.0f,
			bottomCenter.z - spineOffsetX * turnSin));
	m_basicMeshes->DrawBoxMesh();

	// page block: slightly narrower and shallower than the covers, and
	// shifted toward the spine so its left face stays hidden behind it
	const float pageWidth = size.x - spineWidth - pageInset;
	const float pageOffsetX = (spineWidth - pageInset) / 2.0f;
	SetShaderColor(0.95f, 0.94f, 0.90f, 1.0f);
	SetTransformations(
		glm::vec3(pageWidth, size.y - 2.0f * coverThickness, size.z - 2.0f * pageInset),
		0.0f, turnDegrees, 0.0f,
		glm::vec3(bottomCenter.x + pageOffsetX * turnCos,
			bottomCenter.y + size.y / 2.0f,
			bottomCenter.z - pageOffsetX * turnSin));
	m_basicMeshes->DrawBoxMesh();
}